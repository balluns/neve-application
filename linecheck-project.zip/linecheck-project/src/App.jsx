import { useState, useEffect } from 'react';
import payload from './data/linecheck_payload.json';

import Loader from './components/Loader';
import Hero from './components/Hero';
import Welcome from './components/Welcome';
import DesktopMenu from './components/DesktopMenu';
import MobileMenu from './components/MobileMenu';

import './app.css';

function App() {
  const [loading, setLoading] = useState(true);
  const [reveal, setReveal] = useState(false);
  const [isMobileDevice, setIsMobileDevice] = useState(false);

  useEffect(() => {
    // Rileva device mobile
    const ua = navigator.userAgent || navigator.vendor || window.opera;
    const mobileCheck = /android|iphone|ipad|ipod|windows phone/i.test(ua);
    setIsMobileDevice(mobileCheck);

    const t = setTimeout(() => setLoading(false), 1800);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!loading) {
      const r = setTimeout(() => setReveal(true), 100);
      return () => clearTimeout(r);
    }
  }, [loading]);

  if (loading) return <Loader text="Loading..." />;

  return (
    <>
      {isMobileDevice ? (
        <MobileMenu menu={payload.header.menu} />
      ) : (
        <DesktopMenu menu={payload.header.menu} />
      )}

      <main>
        <section className={`reveal reveal-hero ${reveal ? 'is-in' : ''}`}>
          <Hero
            title={payload.hero.title}
            subtitle={payload.hero.subtitle}
            images={payload.hero.images}
          />
        </section>

        <section className={`reveal reveal-welcome ${reveal ? 'is-in' : ''}`}>
          <Welcome
            title={payload.welcome.title}
            richText={payload.welcome.richText}
            ctas={payload.welcome.ctas}
          />
        </section>
      </main>
    </>
  );
}

export default App;
