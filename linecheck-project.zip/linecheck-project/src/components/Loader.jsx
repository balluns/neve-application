import React, { useEffect, useState } from 'react';
import '../styles/loader.css';

export default function Loader({ text = 'Loading...' }) {
  const [closing, setClosing] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setClosing(true), 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`loader ${closing ? 'is-closing' : 'is-active'}`}>
      <span className="loader-text">{text}</span>
    </div>
  );
}
