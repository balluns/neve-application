import { useState, useEffect } from 'react';
import '../styles/mobilemenu.css';

export default function MobileMenu({ menu }) {
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleSubmenu = (i) => {
    setActiveIndex(activeIndex === i ? null : i);
  };

  // ESC per chiudere
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <button
        className="mmenu-btn"
        onClick={() => setOpen(true)}
        aria-label="Apri menu"
        aria-expanded={open}
        aria-controls="mobile-menu-overlay"
      >
        Menu
      </button>

      <div
        id="mobile-menu-overlay"
        className={`mmenu-overlay ${open ? 'open' : ''}`}
        onClick={() => setOpen(false)}
        role="dialog"
        aria-modal="true"
        aria-label="Menu principale"
      >
        <ul
          className="mmenu-list"
          onClick={(e) => e.stopPropagation()}
        >
          {menu.map((item, i) => (
            <li key={i}>
              {item.children ? (
                <>
                  <button
                    className="mmenu-parent"
                    onClick={() => toggleSubmenu(i)}
                    aria-expanded={activeIndex === i}
                    aria-controls={`submenu-${i}`}
                  >
                    {item.label}
                  </button>
                  <ul
                    id={`submenu-${i}`}
                    className={`mmenu-sub ${activeIndex === i ? 'open' : ''}`}
                  >
                    {item.children.map((child, j) => (
                      <li key={j}>
                        <a href={child.url} onClick={() => setOpen(false)}>
                          {child.label}
                        </a>
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <a href={item.url} onClick={() => setOpen(false)}>
                  {item.label}
                </a>
              )}
            </li>
          ))}
        </ul>
      </div>

      {open && (
        <button
          className="mmenu-close"
          onClick={() => setOpen(false)}
          aria-label="Chiudi menu"
        >
          ×
        </button>
      )}
    </>
  );
}
