import React from 'react';
import '../styles/welcome.css'; // qui puoi mettere lo stile specifico della sezione

export default function Welcome({ title, richText, ctas = [] }) {
  return (
    <section className="welcome">
      <div className="welcome-inner">
        {title && <h2 className="welcome-title">{title}</h2>}

        {richText && (
          <div
            className="welcome-text"
            dangerouslySetInnerHTML={{ __html: richText }}
          />
        )}

        {ctas.length > 0 && (
          <div className="welcome-ctas">
            {ctas.map((cta, i) => (
              <a
                key={i}
                href={cta.url || '#'}
                className={`cta cta--${cta.variant || 'primary'}`}
                {...(cta.disabled ? { 'aria-disabled': true, disabled: true } : {})}
              >
                {cta.label}
              </a>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
