import { useState, useEffect } from 'react';
import '../styles/desktopmenu.css';

export default function DesktopMenu({ menu }) {
  const [open, setOpen] = useState(false);

  // ESC per chiudere
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <header className="dc-header">
        <button
          className="dc-menu-btn"
          onClick={() => setOpen(true)}
          aria-label="Apri menu"
          aria-expanded={open}
          aria-controls="desktop-menu-overlay"
        >
          Menu
        </button>
      </header>

      <div
        id="desktop-menu-overlay"
        className={`dc-overlay ${open ? 'open' : ''}`}
        onClick={() => setOpen(false)}
        role="dialog"
        aria-modal="true"
        aria-label="Menu principale"
      >
        <nav
          className="dc-nav"
          aria-label="Main menu"
          onClick={(e) => e.stopPropagation()}
        >
          <ul>
            {menu.map((item, i) => (
              <li key={i}>
                <a href={item.url || '#'} onClick={() => setOpen(false)}>
                  {item.label.toUpperCase()}
                </a>
                {item.children && (
                  <ul>
                    {item.children.map((child, j) => (
                      <li key={j}>
                        <a href={child.url || '#'} onClick={() => setOpen(false)}>
                          {child.label.toUpperCase()}
                        </a>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {open && (
        <button
          className="dc-close-btn"
          onClick={() => setOpen(false)}
          aria-label="Chiudi menu"
        >
          ×
        </button>
      )}
    </>
  );
}
