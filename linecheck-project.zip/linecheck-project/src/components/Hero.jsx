import React from 'react';
import '../styles/hero.css';

export default function Hero({ title, subtitle, images }) {
  return (
    <section className="hero">
      <picture>
        {images?.mobile?.srcset && (
          <source
            media="(max-width: 768px)"
            srcSet={images.mobile.srcset.join(', ')}
          />
        )}
        {images?.desktop?.srcset && (
          <source
            media="(min-width: 769px)"
            srcSet={images.desktop.srcset.join(', ')}
          />
        )}
        <img
          className="hero-media"
          src={images?.desktop?.src}
          alt={title || ''}
          loading="lazy"
        />
      </picture>

      <div className="hero-text">
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
    </section>
  );
}
