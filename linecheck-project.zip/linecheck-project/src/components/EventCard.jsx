import './eventcard.css';

function EventCard({ title, date, venue, prices, buyUrl }) {
  const firstPrice = prices?.[0];
  return (
    <div className="event-card">
      <h2>{title}</h2>
      <p><strong>Data:</strong> {date}</p>
      <p><strong>Luogo:</strong> {venue}</p>
      {firstPrice && (
        <p><strong>Prezzo:</strong> {firstPrice.price} {firstPrice.currency}</p>
      )}
      <a href={buyUrl} target="_blank" rel="noopener noreferrer">Acquista biglietto</a>
    </div>
  );
}

export default EventCard;
